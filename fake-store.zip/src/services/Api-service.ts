import AxiosService from "./Axios-service";

class ApiService { 
    get<T>(endpoint:string){
        return AxiosService.get<T>(endpoint)
    }
}

export default new ApiService();