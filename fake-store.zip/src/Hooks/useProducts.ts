import { useEffect, useState } from "react";
import ApiService from "../services/Api-service";

interface Products{
    products:Product[]
}

interface Product {
    id: number,
    title: string,
    price: number,
    description: string
    images: string[]
    
}

const useProducts = () => {
    let [data,setData] = useState<Product[]>([] as Product[])
    let [error,setError] = useState('')
    let [Loading,setLoading] = useState(false)
    useEffect(()=>{
        setLoading(true)
        ApiService.get<Product[]>('/products')
            .then(res => {setData(res.data);setLoading(false)})
            .catch(err => {setError(err.message);setLoading(false)})
    },[])

    return {data,error,Loading}
}

export default useProducts;