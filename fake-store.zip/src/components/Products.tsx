import useProducts from "../Hooks/useProducts"
import ApiService from "../services/Api-service"

const Products = () => {
    const {data,Loading,error} = useProducts()
    return(
        <>
            {error && <p className="text-danger">{error}</p>}
            <div className="container">
                <div className="row row-cols-md-3 row-cols-2 gx-md-4 gy-5 g-3 my-0">
                    {data.map(product => 
                        
                                <div className="col">
                                    <div className="card overflow-hidden" style={{width: '18rem'}}>
                                        <img src={product.images[0]} className="card-img-top" alt="..." />
                                        <div className="card-body">
                                            <h5 className="card-title">{product.title}</h5>
                                            {/* <p className="card-text">{product.description}</p>
                                            <a href="#" className="btn btn-primary">Go somewhere</a> */}
                                        </div>
                                    </div>
                                </div>       
                    )}
                </div>
             </div>
            
        </>
    )
}

export default Products